def validateAcc(AccNo):
    if len(AccNo)==10:
        return 'PASS'
    else:
        return 'FAIL'